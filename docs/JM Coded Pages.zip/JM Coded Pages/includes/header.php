<?php
session_start();
// Security Check: If no user_id is in session, kick them back to login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elder Shield - Dashboard</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net" rel="stylesheet">
    <style>
        /* Large-UI Accessibility for Elder Shield */
        body { font-size: 1.2rem; background-color: #f4f7f6; }
        .nav-link { font-weight: bold; }
        .btn-lg { padding: 20px; font-size: 1.5rem; } /* Extra large buttons for elderly users */
        .card-title { font-size: 1.6rem; color: #0d6efd; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">🛡️ Elder Shield</a>
        <div class="d-flex text-white align-items-center">
            <span class="me-3">Role: <?php echo ucfirst($_SESSION['role']); ?></span>
            <a href="../auth/logout.php" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<div class="container">
