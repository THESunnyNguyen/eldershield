<?php
// This script fetches alerts from the database
// We assume a 'notifications' table exists with: alert_id, user_id, message, is_read, created_at

$u_id = $_SESSION['user_id'];
$notif_sql = "SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC LIMIT 5";
$n_stmt = $conn->prepare($notif_sql);
$n_stmt->bind_param("i", $u_id);
$n_stmt->execute();
$notifications = $n_stmt->get_result();

if ($notifications->num_rows > 0): 
?>
    <div class="row mb-4">
        <div class="col-12">
            <?php while($alert = $notifications->fetch_assoc()): ?>
                <div class="alert alert-warning alert-dismissible fade show shadow-sm border-start border-warning border-5" role="alert">
                    <strong>🔔 Security Alert:</strong> <?php echo $alert['message']; ?>
                    <a href="mark_read.php?id=<?php echo $alert['alert_id']; ?>" class="btn-close" aria-label="Close"></a>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
<?php endif; ?>
