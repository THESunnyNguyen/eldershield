</div> <!-- End Container -->

<footer class="mt-5 py-4 text-center text-muted">
    <p>&copy; <?php echo date("Y"); ?> Elder Shield Project - Class Web Apps</p>
</footer>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net"></script>
</body>
</html>
