<?php
// Database configuration - Sunny will provide these values later
$host = "localhost";
$db_user = "root";      // Default for MAMP/XAMPP
$db_pass = "";          // Default is empty for XAMPP, 'root' for MAMP
$db_name = "elder_shield"; 

// Create connection
$conn = new mysqli($host, $db_user, $db_pass, $db_name);

// Check connection
if ($conn->connect_error) {
    // In production, we don't show the error to the user for security.
    // For your class project, this helps you debug!
    die("Database connection failed: " . $conn->connect_error);
}

// Set charset to utf8mb4 to handle special characters (emojis/symbols in SMS)
$conn->set_charset("utf8mb4");
?>
