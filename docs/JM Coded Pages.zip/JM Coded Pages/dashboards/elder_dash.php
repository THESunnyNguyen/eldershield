<?php 
// 1. Include the Header (which handles session_start and security)
include('../includes/header.php'); 

// 2. Include the Database Connection (needed for notifications)
require_once('../includes/db_connect.php');

// 3. INSERT NOTIFICATION SYSTEM HERE
// This ensures alerts appear at the very top of the dashboard
include('../includes/notifications.php'); 
?>

<!-- 4. Main Dashboard Content -->
<div class="row">
    <div class="col-12 mb-4">
        <h1 class="display-4 fw-bold">Welcome Back!</h1>
        <p class="lead fs-4 text-muted">How can we help keep you safe today?</p>
    </div>
</div>

<div class="row g-4">
    <!-- ACTION 1: Submit a New Scam -->
    <div class="col-md-6">
        <div class="card h-100 border-primary shadow-sm border-4">
            <div class="card-body text-center p-5">
                <h2 class="card-title mb-3">🔍 Check a Message</h2>
                <p class="fs-5">Received a scary text, email, or call? Let our AI check it for you.</p>
                <a href="submit_report.php" class="btn btn-primary btn-lg w-100 py-3 fw-bold">Start New Scan</a>
            </div>
        </div>
    </div>

    <!-- ACTION 2: View Past Results -->
    <div class="col-md-6">
        <div class="card h-100 border-secondary shadow-sm">
            <div class="card-body text-center p-5">
                <h2 class="card-title mb-3">📋 My History</h2>
                <p class="fs-5 text-muted">Look at your previous reports and see what the AI detective found.</p>
                <a href="view_reports.php" class="btn btn-outline-secondary btn-lg w-100 py-3">View My Reports</a>
            </div>
        </div>
    </div>
</div>

<?php 
// 5. Include the Footer to close the HTML tags
include('../includes/footer.php'); 
?>

