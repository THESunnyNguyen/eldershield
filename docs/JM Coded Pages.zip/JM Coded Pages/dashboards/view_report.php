<?php include('../includes/header.php'); ?>
<?php require_once('../includes/db_connect.php'); ?>

<div class="row">
    <div class="col-12 d-flex justify-content-between align-items-center mb-4">
        <h1>My Security History</h1>
        <a href="submit_report.php" class="btn btn-primary btn-lg">+ New Scan</a>
    </div>
</div>

<?php if(isset($_GET['msg']) && $_GET['msg'] == 'submitted'): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> Your report has been sent to our AI for analysis.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0" style="font-size: 1.2rem;">
                <thead class="table-light">
                    <tr>
                        <th class="p-3">Date</th>
                        <th class="p-3">Type</th>
                        <th class="p-3">Status</th>
                        <th class="p-3 text-center">Scam Risk</th>
                        <th class="p-3 text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $u_id = $_SESSION['user_id'];
                    // Query to get reports and AI scores if they exist
                    $sql = "SELECT r.*, a.scam_probability 
                            FROM scam_reports r 
                            LEFT JOIN ai_scam_analysis a ON r.report_id = a.report_id 
                            WHERE r.user_id = ? 
                            ORDER BY r.submitted_at DESC";
                    
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $u_id);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0):
                        while($row = $result->fetch_assoc()):
                            // Logic for Risk Badge Color
                            $badge_class = "bg-secondary";
                            $risk_text = "Pending";
                            
                            if($row['scam_probability'] !== null) {
                                if($row['scam_probability'] > 70) $badge_class = "bg-danger";
                                elseif($row['scam_probability'] > 30) $badge_class = "bg-warning text-dark";
                                else $badge_class = "bg-success";
                                $risk_text = $row['scam_probability'] . "%";
                            }
                    ?>
                    <tr>
                        <td class="p-3"><?php echo date('M d, Y', strtotime($row['submitted_at'])); ?></td>
                        <td class="p-3"><span class="badge bg-info text-dark"><?php echo $row['content_type']; ?></span></td>
                        <td class="p-3"><?php echo $row['status']; ?></td>
                        <td class="p-3 text-center">
                            <span class="badge <?php echo $badge_class; ?> rounded-pill p-2" style="min-width: 60px;">
                                <?php echo $risk_text; ?>
                            </span>
                        </td>
                        <td class="p-3 text-end">
                            <a href="report_details.php?id=<?php echo $row['report_id']; ?>" class="btn btn-outline-primary btn-sm">View Details</a>
                        </td>
                    </tr>
                    <?php 
                        endwhile; 
                    else: 
                    ?>
                    <tr>
                        <td colspan="5" class="text-center p-5 text-muted">You haven't submitted any reports yet.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include('../includes/footer.php'); ?>
