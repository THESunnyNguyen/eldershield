<?php include('../includes/header.php'); ?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow border-0">
            <div class="card-header bg-primary text-white py-3">
                <h3 class="mb-0">🛡️ Submit for AI Analysis</h3>
            </div>
            <div class="card-body p-4">
                <p class="text-muted">Paste the suspicious message or describe the phone call below. Our AI will analyze it immediately.</p>
                
                <form action="process_report.php" method="POST">
                    <!-- Type of Scam -->
                    <div class="mb-4">
                        <label class="form-label fw-bold">What are we checking?</label>
                        <select name="content_type" class="form-select form-select-lg" required>
                            <option value="">-- Select Type --</option>
                            <option value="SMS">Text Message (SMS)</option>
                            <option value="Email">Email Content</option>
                            <option value="Call">Phone Call Summary</option>
                            <option value="URL">Website Link (URL)</option>
                        </select>
                    </div>

                    <!-- The Content -->
                    <div class="mb-4">
                        <label class="form-label fw-bold">Paste the Message or Details Here:</label>
                        <textarea name="content_text" class="form-control" rows="6" placeholder="Example: Your bank account is frozen. Click here to verify..." required></textarea>
                    </div>

                    <!-- Submit Button -->
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-success btn-lg">
                            🔍 Analyze for Scams
                        </button>
                        <a href="elder_dash.php" class="btn btn-outline-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include('../includes/footer.php'); ?>
