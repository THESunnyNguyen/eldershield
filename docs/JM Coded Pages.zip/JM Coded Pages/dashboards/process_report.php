<?php
session_start();
require_once('../includes/db_connect.php');

// Security Check: Ensure only logged-in users can submit
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Capture and Sanitize Inputs
    // htmlspecialchars prevents Cross-Site Scripting (XSS)
    $user_id = $_SESSION['user_id'];
    $content_type = $_POST['content_type']; 
    $content_text = htmlspecialchars($_POST['content_text'], ENT_QUOTES, 'UTF-8');
    $status = "Pending AI Analysis"; // Initial status

    // 2. Prepared Statement to insert the report safely
    $sql = "INSERT INTO scam_reports (user_id, content_type, content_text, status, submitted_at) 
            VALUES (?, ?, ?, ?, NOW())";
    
    if ($stmt = $conn->prepare($sql)) {
        // "isss" stands for integer, string, string, string
        $stmt->bind_param("isss", $user_id, $content_type, $content_text, $status);
        
        if ($stmt->execute()) {
            // Success! Redirect to the history page to see the new entry
            header("Location: view_reports.php?msg=submitted");
        } else {
            echo "Error submitting report: " . $stmt->error;
        }
        $stmt->close();
    }
    
    $conn->close();
    exit();
}
