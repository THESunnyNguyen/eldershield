<?php 
// 1. Include the Header (Session/Security check)
include('../includes/header.php'); 

// 2. Database connection for alerts
require_once('../includes/db_connect.php');

// 3. INSERT NOTIFICATION SYSTEM HERE
// This ensures any new high-risk alerts appear at the very top
include('../includes/notifications.php'); 
?>

<div class="row mb-4">
    <div class="col-md-8">
        <h1 class="display-5 fw-bold text-primary">Caregiver Monitoring</h1>
        <p class="lead">Reviewing safety incidents for: <strong>John Doe (Elderly User)</strong></p>
    </div>
    <div class="col-md-4 text-md-end pt-3">
        <a href="submit_report.php" class="btn btn-warning btn-lg shadow-sm fw-bold">Submit Incident for Elder</a>
    </div>
</div>

<div class="row g-4 mb-5">
    <!-- Summary Stats -->
    <div class="col-md-4">
        <div class="card bg-danger text-white shadow border-0">
            <div class="card-body text-center p-4">
                <h5 class="card-title text-white">High Risk Alerts</h5>
                <p class="display-4 fw-bold mb-0">2</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-success text-white shadow border-0">
            <div class="card-body text-center p-4">
                <h5 class="card-title text-white">Safe Reports</h5>
                <p class="display-4 fw-bold mb-0">12</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-white border-0 shadow-sm">
            <div class="card-body text-center p-4">
                <h5 class="card-title text-muted">Total Monitored</h5>
                <p class="display-4 fw-bold text-dark mb-0">14</p>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-header bg-white py-3 border-bottom">
        <h4 class="mb-0 fw-bold">Recent Incident Feed</h4>
    </div>
    <div class="card-body p-0">
        <ul class="list-group list-group-flush">
            <?php
            // Fetch the most recent reports for the monitoring feed
            $sql = "SELECT r.*, a.scam_probability, a.scam_category 
                    FROM scam_reports r 
                    LEFT JOIN ai_scam_analysis a ON r.report_id = a.report_id 
                    ORDER BY r.submitted_at DESC LIMIT 10";
            
            $result = $conn->query($sql);

            if ($result->num_rows > 0):
                while($row = $result->fetch_assoc()):
                    $risk_color = "text-muted";
                    if($row['scam_probability'] > 70) $risk_color = "text-danger fw-bold";
            ?>
            <li class="list-group-item p-4 hover-bg">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <span class="badge bg-secondary mb-2"><?php echo $row['content_type']; ?></span>
                        <h5 class="mb-1 fw-bold text-dark"><?php echo $row['scam_category'] ?? 'Awaiting Classification'; ?></h5>
                        <p class="text-muted small mb-2">Submitted: <?php echo date('M d, Y | g:i a', strtotime($row['submitted_at'])); ?></p>
                        <p class="mb-0 text-truncate" style="max-width: 500px;">"<?php echo $row['content_text']; ?>"</p>
                    </div>
                    <div class="text-end">
                        <p class="mb-0 small text-muted">AI Risk Score</p>
                        <h3 class="<?php echo $risk_color; ?> mb-1"><?php echo $row['scam_probability'] ?? '--'; ?>%</h3>
                        <a href="report_details.php?id=<?php echo $row['report_id']; ?>" class="btn btn-sm btn-primary px-3">Full Analysis</a>
                    </div>
                </div>
            </li>
            <?php endwhile; else: ?>
                <li class="list-group-item p-5 text-center text-muted">No incidents recorded for this user.</li>
            <?php endif; ?>
        </ul>
    </div>
</div>

<?php 
// 4. Include the Footer
include('../includes/footer.php'); 
?>
