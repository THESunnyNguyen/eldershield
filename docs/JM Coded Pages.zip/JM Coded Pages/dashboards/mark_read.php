<?php
session_start();
require_once('../includes/db_connect.php');

$notif_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($notif_id > 0) {
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE alert_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $notif_id, $_SESSION['user_id']);
    $stmt->execute();
}

// Redirect back to wherever they came from
header("Location: " . $_SERVER['HTTP_REFERER']);
exit();
?>
