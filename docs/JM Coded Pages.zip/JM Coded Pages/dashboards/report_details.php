<?php include('../includes/header.php'); ?>
<?php require_once('../includes/db_connect.php'); ?>

<?php
// 1. Get the Report ID from the URL
$report_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// 2. Fetch the report and the AI analysis using a JOIN
$sql = "SELECT r.*, a.* 
        FROM scam_reports r 
        LEFT JOIN ai_scam_analysis a ON r.report_id = a.report_id 
        WHERE r.report_id = ? LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $report_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

// Security: If report doesn't exist, send them back
if (!$data) {
    header("Location: view_reports.php");
    exit();
}

// 3. Determine Risk Level Color
$risk_score = $data['scam_probability'] ?? 0;
$risk_color = "bg-success"; // Default safe
if ($risk_score > 70) $risk_color = "bg-danger";
elseif ($risk_score > 30) $risk_color = "bg-warning text-dark";
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <!-- Back Button -->
        <a href="view_reports.php" class="btn btn-outline-secondary mb-4">← Back to My History</a>

        <!-- Header Card: The Verdict -->
        <div class="card shadow border-0 mb-4">
            <div class="card-body text-center p-5">
                <h4 class="text-muted text-uppercase mb-2">AI Security Verdict</h4>
                <div class="display-1 fw-bold <?php echo str_replace('bg-', 'text-', $risk_color); ?>">
                    <?php echo $risk_score; ?>%
                </div>
                <p class="h3 mb-4">Scam Likelihood Score</p>
                <div class="progress mb-3" style="height: 25px;">
                    <div class="progress-bar <?php echo $risk_color; ?>" role="progressbar" style="width: <?php echo $risk_score; ?>%"></div>
                </div>
                <p class="lead fw-bold">Classification: <?php echo $data['scam_category'] ?? 'Processing...'; ?></p>
            </div>
        </div>

        <!-- Section: AI Explanation (Plain Language) -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body p-4">
                <h3 class="card-title text-primary border-bottom pb-2">🔍 Why is this a risk?</h3>
                <p class="card-text fs-5">
                    <?php echo $data['explanation_simple'] ?? 'The AI is currently reviewing the message details. Please check back in a moment.'; ?>
                </p>
            </div>
        </div>

        <!-- Section: Actionable Guidance -->
        <div class="card shadow-sm border-0 border-start border-warning border-5 mb-4">
            <div class="card-body p-4">
                <h3 class="card-title text-warning">🛡️ What to Do Next</h3>
                <div class="fs-5 p-3 bg-light rounded">
                    <?php echo $data['recommended_action'] ?? 'Do not click any links or share personal info until the analysis is complete.'; ?>
                </div>
            </div>
        </div>

        <!-- Section: Original Submission -->
        <div class="card shadow-sm border-0 bg-light">
            <div class="card-body">
                <h5 class="text-muted">Your Original Submission:</h5>
                <blockquote class="blockquote mb-0 italic">
                    <p>"<?php echo nl2br($data['content_text']); ?>"</p>
                    <footer class="blockquote-footer mt-2">Submitted via <?php echo $data['content_type']; ?></footer>
                </blockquote>
            </div>
        </div>
    </div>
</div>

<?php include('../includes/footer.php'); ?>
