<?php include('../includes/header.php'); ?>
<?php require_once('../includes/db_connect.php'); ?>

<div class="row mb-4">
    <div class="col-md-8">
        <h1 class="display-6 fw-bold">System Administration</h1>
        <p class="text-muted">Manage user accounts and caregiver assignments.</p>
    </div>
    <div class="col-md-4 text-md-end">
        <button class="btn btn-success btn-lg" data-bs-toggle="modal" data-bs-target="#addUserModal">+ Create New User</button>
    </div>
</div>

<!-- User Management Table -->
<div class="card shadow-sm border-0">
    <div class="card-header bg-dark text-white py-3">
        <h5 class="mb-0">User Lifecycle Management</h5>
    </div>
    <div class="card-body p-0">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th class="ps-4">ID</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Created At</th>
                    <th class="text-end pe-4">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM users ORDER BY created_at DESC";
                $result = $conn->query($sql);

                while($user = $result->fetch_assoc()):
                    $role_badge = ($user['role'] == 'admin') ? 'bg-dark' : (($user['role'] == 'caregiver') ? 'bg-primary' : 'bg-info text-dark');
                ?>
                <tr>
                    <td class="ps-4"><?php echo $user['user_id']; ?></td>
                    <td class="fw-bold"><?php echo $user['full_name']; ?></td>
                    <td><?php echo $user['email']; ?></td>
                    <td><span class="badge <?php echo $role_badge; ?>"><?php echo ucfirst($user['role']); ?></span></td>
                    <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                    <td class="text-end pe-4">
                        <button class="btn btn-sm btn-outline-secondary">Edit</button>
                        <button class="btn btn-sm btn-outline-danger ms-1" onclick="confirmDelete(<?php echo $user['user_id']; ?>)">Delete</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Placeholder for Account Linking Logic -->
<div class="mt-5 p-4 bg-light border rounded shadow-sm">
    <h3>🔗 Link Accounts</h3>
    <p class="text-muted">Connect a Caregiver to an Elderly User to enable real-time monitoring.</p>
    <form action="link_users.php" method="POST" class="row g-3">
        <div class="col-md-5">
            <select name="caregiver_id" class="form-select" required>
                <option value="">Select Caregiver...</option>
                <!-- PHP logic would loop through caregiver roles here -->
            </select>
        </div>
        <div class="col-md-5">
            <select name="elder_id" class="form-select" required>
                <option value="">Select Elderly User...</option>
                <!-- PHP logic would loop through elder roles here -->
            </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-primary w-100">Link Accounts</button>
        </div>
    </form>
</div>

<script>
function confirmDelete(id) {
    if(confirm('Are you sure you want to permanently delete this user?')) {
        window.location.href = 'delete_user.php?id=' + id;
    }
}
</script>

<?php include('../includes/footer.php'); ?>
