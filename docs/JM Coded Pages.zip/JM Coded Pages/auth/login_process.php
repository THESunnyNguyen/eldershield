<?php
session_start();
require_once('../includes/db_connect.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Sanitize Input
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    // 2. Prepared Statement to prevent SQL Injection
    $stmt = $conn->prepare("SELECT user_id, password_hash, role FROM users WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        // 3. Verify Password
        if (password_verify($password, $user['password_hash'])) {
            
            // 4. Set Session Variables
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['role'] = $user['role'];

            // 5. Route based on role
            switch ($user['role']) {
                case 'admin':
                    header("Location: ../dashboards/admin_dash.php");
                    break;
                case 'caregiver':
                    header("Location: ../dashboards/caregiver_dash.php");
                    break;
                case 'elderly':
                    header("Location: ../dashboards/elder_dash.php");
                    break;
                default:
                    header("Location: ../index.php");
            }
            exit();
        }
    }

    // If login fails
    $_SESSION['error'] = "Failed to Login";
    header("Location: ../index.php");
    exit();
}
